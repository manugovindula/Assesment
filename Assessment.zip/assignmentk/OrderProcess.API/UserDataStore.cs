﻿using System.Collections.Generic;
using OrderProcess.API.Models;

namespace OrderProcess.API
{
    // public class UserDataStore
    // {
    //     public static UserDataStore Current { get; } = new UserDataStore();
    //
    //     public List<UserDto> Cities { get; set; }
    //
    //     public  List<CreateOrderDto> Orders { get; set; }
    //
    //     public UserDataStore()
    //     {
    //
    //         Orders = new List<CreateOrderDto>()
    //         {
    //             new CreateOrderDto()
    //             {
    //                 Id =1,
    //                 User = new UserDto()
    //                 {
    //                     Id = 1,
    //                     Name = "Sam",
    //                 }
    //             },
    //             new CreateOrderDto()
    //             {
    //                 Id =2,
    //                 User = new UserDto()
    //                 {
    //                     Id = 1,
    //                     Name = "Sam",
    //                 }
    //             },
    //             new CreateOrderDto()
    //             {
    //                 Id =3,
    //                 User = new UserDto()
    //                 {
    //                     Id = 2,
    //                     Name = "Bob",
    //                 }
    //             }
    //         };
    //         // init dummy data
    //         Cities = new List<UserDto>()
    //         {
    //             new UserDto()
    //             {
    //                  Id = 3,
    //                  Name = "Ben",
    //             },
    //             new UserDto()
    //             {
    //                 Id = 4,
    //                 Name = "Steve"
    //      
    //             },
    //             new UserDto()
    //             {
    //                 Id= 5,
    //                 Name = "Raj",
    //             }
    //         };
    //     }
    //
    // }

}
